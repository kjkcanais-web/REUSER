import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import {
  PlusCircle,
  RotateCcw,
  Settings,
  ShieldCheck,
  Zap,
  Smartphone,
  Loader2,
  Trash2,
  Play,

  Check,
  CheckSquare,
  Square,
} from "lucide-react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { APPS_DO_DISPOSITIVO, STORAGE_KEY, iniciais, type AppItem } from "@/lib/apps";
import banner from "@/assets/kjk-reuser-banner.jpg";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "KJK Reuser — Painel de Apps" },
      {
        name: "description",
        content:
          "Painel KJK Reuser para adicionar apps do dispositivo, resetar apps e ajustar configurações.",
      },
      { property: "og:title", content: "KJK Reuser — Painel de Apps" },
      {
        property: "og:description",
        content: "Adicione, resete e configure seus apps pelo painel KJK Reuser.",
      },
    ],
  }),
  component: Index,
});

const destaques = [
  { icone: RotateCcw, titulo: "Reutilize", texto: "Com segurança" },
  { icone: ShieldCheck, titulo: "Mais", texto: "Estabilidade" },
  { icone: Zap, titulo: "Desempenho", texto: "Otimizado" },
  { icone: Smartphone, titulo: "Compatível", texto: "Com seu app" },
];

function Index() {
  const [adicionados, setAdicionados] = useState<AppItem[]>([]);
  const [aberto, setAberto] = useState(false);
  const [buscando, setBuscando] = useState(false);
  const [encontrados, setEncontrados] = useState<AppItem[]>([]);
  const [selecionados, setSelecionados] = useState<string[]>([]);

  useEffect(() => {
    try {
      const salvo = localStorage.getItem(STORAGE_KEY);
      if (salvo) setAdicionados(JSON.parse(salvo) as AppItem[]);
    } catch {
      /* ignora leitura inválida */
    }
  }, []);

  function persistir(lista: AppItem[]) {
    setAdicionados(lista);
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(lista));
    } catch {
      /* armazenamento indisponível */
    }
  }

  function abrirBusca() {
    setAberto(true);
    setBuscando(true);
    setEncontrados([]);
    window.setTimeout(() => {
      setEncontrados(APPS_DO_DISPOSITIVO);
      setBuscando(false);
    }, 900);
  }

  function adicionar(app: AppItem) {
    if (adicionados.some((a) => a.pacote === app.pacote)) return;
    persistir([...adicionados, app]);
    toast.success(`${app.nome} adicionado`);
  }

  function remover(pacote: string) {
    persistir(adicionados.filter((a) => a.pacote !== pacote));
    setSelecionados((s) => s.filter((p) => p !== pacote));
  }

  function alternarSelecao(pacote: string) {
    setSelecionados((s) =>
      s.includes(pacote) ? s.filter((p) => p !== pacote) : [...s, pacote],
    );
  }

  function resetar(app: AppItem) {
    toast.success(`${app.nome} resetado`, { description: "Dados do app limpos." });
  }

  function iniciarApp(app: AppItem) {
    toast.success(`Abrindo ${app.nome}`, { description: app.pacote });
  }


  function resetarSelecionados() {
    if (!adicionados.length) {
      toast.info("Nenhum app adicionado ainda");
      return;
    }
    const alvos = adicionados.filter((a) => selecionados.includes(a.pacote));
    if (!alvos.length) {
      toast.info("Selecione os apps que deseja resetar", {
        description: "Use o botão de seleção ao lado da lixeira.",
      });
      return;
    }
    alvos.forEach(resetar);
  }

  return (
    <main className="min-h-screen bg-background font-sans text-foreground">
      <div className="mx-auto w-full max-w-5xl px-4 py-8 sm:py-12">
        <section className="overflow-hidden rounded-xl border border-border shadow-[var(--shadow-panel)]">
          <img
            src={banner}
            alt="KJK Reuser — Reutilize. Renove. Economize."
            className="w-full"
          />
        </section>

        <h1 className="sr-only">KJK Reuser — Painel de Apps</h1>

        <section className="mt-8 grid gap-4 sm:grid-cols-3">
          <Button variant="action" size="tile" className="font-display" onClick={abrirBusca}>
            <PlusCircle />
            <span className="text-base">Adicionar App</span>
            <span className="text-[11px] font-normal normal-case tracking-normal opacity-80">
              Buscar apps do dispositivo
            </span>
          </Button>
          <Button
            variant="steel"
            size="tile"
            className="font-display"
            onClick={resetarSelecionados}
          >
            <RotateCcw />
            <span className="text-base">Resetar App</span>
            <span className="text-[11px] font-normal normal-case tracking-normal opacity-80">
              {selecionados.length
                ? `${selecionados.length} selecionado(s)`
                : "Selecione os apps na lista"}
            </span>
          </Button>
          <Button
            variant="steel"
            size="tile"
            className="font-display"
            onClick={() => toast.info("Configurações em breve")}
          >
            <Settings />
            <span className="text-base">Configurações</span>
            <span className="text-[11px] font-normal normal-case tracking-normal opacity-80">
              Preferências e ajustes
            </span>
          </Button>
        </section>

        <section className="mt-10">
          <div className="flex items-center justify-between">
            <h2 className="font-display text-lg uppercase tracking-widest">Apps adicionados</h2>
            <Badge variant="outline">{adicionados.length}</Badge>
          </div>

          {adicionados.length === 0 ? (
            <div className="mt-4 rounded-xl border border-dashed border-border bg-surface/60 px-6 py-12 text-center">
              <Smartphone className="mx-auto size-8 text-muted-foreground" />
              <p className="mt-3 text-sm text-muted-foreground">
                Nenhum app aqui ainda. Toque em “Adicionar App” para buscar os apps do dispositivo.
              </p>
            </div>
          ) : (
            <ul className="mt-4 grid gap-3 sm:grid-cols-2">
              {adicionados.map((app) => (
                <li
                  key={app.pacote}
                  className="flex items-center gap-3 rounded-xl border border-border bg-surface p-4"
                >
                  <span className="flex size-11 shrink-0 items-center justify-center rounded-lg bg-[image:var(--gradient-red)] font-display text-sm text-primary-foreground">
                    {iniciais(app.nome)}
                  </span>
                  <div className="min-w-0 flex-1">
                    <p className="truncate font-medium">{app.nome}</p>
                    <p className="truncate text-xs text-muted-foreground">
                      {app.pacote} · v{app.versao}
                    </p>
                  </div>
                  <Button size="icon" variant="ghost" onClick={() => resetar(app)} title="Resetar">
                    <RotateCcw />
                  </Button>
                  <Button
                    size="icon"
                    variant="ghost"
                    onClick={() => remover(app.pacote)}
                    title="Remover"
                  >
                    <Trash2 />
                  </Button>
                  <Button
                    size="icon"
                    variant="ghost"
                    onClick={() => iniciarApp(app)}
                    title="Iniciar app"
                  >
                    <Play />
                  </Button>

                  <Button
                    size="icon"
                    variant="ghost"
                    aria-pressed={selecionados.includes(app.pacote)}
                    onClick={() => alternarSelecao(app.pacote)}
                    title="Selecionar para resetar"
                    className={
                      selecionados.includes(app.pacote) ? "text-primary" : "text-muted-foreground"
                    }
                  >
                    {selecionados.includes(app.pacote) ? <CheckSquare /> : <Square />}
                  </Button>
                </li>
              ))}
            </ul>
          )}
        </section>

        <section className="mt-10 grid grid-cols-2 gap-3 rounded-xl border border-border bg-surface p-5 sm:grid-cols-4">
          {destaques.map((item) => (
            <div key={item.titulo} className="flex items-center gap-3">
              <item.icone className="size-6 shrink-0 text-primary" />
              <div className="leading-tight">
                <p className="font-display text-sm uppercase tracking-wide">{item.titulo}</p>
                <p className="text-xs text-muted-foreground">{item.texto}</p>
              </div>
            </div>
          ))}
        </section>
      </div>

      <Dialog open={aberto} onOpenChange={setAberto}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="font-display uppercase tracking-widest">
              Apps do dispositivo
            </DialogTitle>
            <DialogDescription>
              Selecione um app instalado para adicionar ao painel.
            </DialogDescription>
          </DialogHeader>

          {buscando ? (
            <div className="flex items-center justify-center gap-3 py-12 text-sm text-muted-foreground">
              <Loader2 className="size-5 animate-spin text-primary" />
              Buscando apps instalados...
            </div>
          ) : (
            <ScrollArea className="h-80 pr-3">
              <ul className="space-y-2">
                {encontrados.map((app) => {
                  const jaTem = adicionados.some((a) => a.pacote === app.pacote);
                  return (
                    <li key={app.pacote}>
                      <button
                        type="button"
                        disabled={jaTem}
                        onClick={() => adicionar(app)}
                        className="flex w-full items-center gap-3 rounded-lg border border-border bg-surface p-3 text-left transition-colors hover:border-primary/60 disabled:opacity-50"
                      >
                        <span className="flex size-10 shrink-0 items-center justify-center rounded-lg bg-accent font-display text-xs">
                          {iniciais(app.nome)}
                        </span>
                        <span className="min-w-0 flex-1">
                          <span className="block truncate text-sm font-medium">{app.nome}</span>
                          <span className="block truncate text-xs text-muted-foreground">
                            {app.pacote}
                          </span>
                        </span>
                        {jaTem ? (
                          <Check className="size-4 text-primary" />
                        ) : (
                          <PlusCircle className="size-4 text-muted-foreground" />
                        )}
                      </button>
                    </li>
                  );
                })}
              </ul>
            </ScrollArea>
          )}
        </DialogContent>
      </Dialog>
    </main>
  );
}
