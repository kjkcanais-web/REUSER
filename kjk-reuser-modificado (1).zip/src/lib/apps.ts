export type AppItem = {
  pacote: string;
  nome: string;
  versao: string;
};

/**
 * Catálogo de apps "detectáveis" no dispositivo.
 * Em um navegador não é possível ler os apps realmente instalados;
 * esta lista simula a varredura do dispositivo.
 */
export const APPS_DO_DISPOSITIVO: AppItem[] = [
  { pacote: "com.integration.unitvsiptv", nome: "UniTV IPTV", versao: "3.4.1" },
  { pacote: "com.kjk.reuser.agent", nome: "KJK Agent", versao: "1.0.8" },
  { pacote: "com.android.settings", nome: "Configurações do Sistema", versao: "13.0" },
  { pacote: "com.google.android.youtube", nome: "YouTube", versao: "18.45.43" },
  { pacote: "com.whatsapp", nome: "WhatsApp", versao: "2.24.5" },
  { pacote: "org.videolan.vlc", nome: "VLC Player", versao: "3.5.4" },
  { pacote: "com.netflix.mediaclient", nome: "Netflix", versao: "8.92.0" },
  { pacote: "com.spotify.music", nome: "Spotify", versao: "8.9.12" },
];

export const STORAGE_KEY = "kjk-reuser-apps";

export function iniciais(nome: string) {
  return nome
    .split(" ")
    .slice(0, 2)
    .map((p) => p[0])
    .join("")
    .toUpperCase();
}
