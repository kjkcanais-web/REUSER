// Entrada usada apenas no build offline (APK/Capacitor).
// Renderiza o app como SPA puro, sem SSR.
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { StrictMode } from "react";
import { createRoot } from "react-dom/client";

import { Toaster } from "@/components/ui/sonner";
import { Route as IndexRoute } from "@/routes/index";
import "./styles.css";

const queryClient = new QueryClient();
const Page = IndexRoute.options.component as () => React.ReactNode;

createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <QueryClientProvider client={queryClient}>
      <Page />
      <Toaster />
    </QueryClientProvider>
  </StrictMode>,
);
