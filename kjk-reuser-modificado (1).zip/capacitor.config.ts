import type { CapacitorConfig } from "@capacitor/cli";

const config: CapacitorConfig = {
  appId: "com.kjk.reuser",
  appName: "KJK Reuser",
  webDir: "dist-apk",
  android: {
    allowMixedContent: true,
  },
};

export default config;
