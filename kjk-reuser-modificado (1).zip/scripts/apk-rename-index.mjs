// Capacitor exige dist-apk/index.html
import { renameSync, existsSync } from "node:fs";
if (existsSync("dist-apk/index.apk.html")) renameSync("dist-apk/index.apk.html", "dist-apk/index.html");
