// Build estático (SPA) usado só para gerar o app Android/APK via Capacitor.
// O app web normal continua usando vite.config.ts (TanStack Start + SSR).
import { fileURLToPath } from "node:url";
import react from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";
import { defineConfig } from "vite";

export default defineConfig({
  base: "./",
  plugins: [react(), tailwindcss()],
  resolve: {
    alias: {
      "@": fileURLToPath(new URL("./src", import.meta.url)),
    },
  },
  build: {
    outDir: "dist-apk",
    emptyOutDir: true,
    rollupOptions: {
      input: fileURLToPath(new URL("./index.apk.html", import.meta.url)),
    },
  },
});
